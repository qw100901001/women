import re
import time
import requests
import execjs
import json
import csv
from datetime import datetime, timedelta

from bs4 import BeautifulSoup

headers = {
    "authority": "edith.xiaohongshu.com",
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "content-type": "application/json;charset=UTF-8",
    "origin": "https://www.xiaohongshu.com",
    "referer": "https://www.xiaohongshu.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
}

cookies = {
    "sec_poison_id": "7869d8b9-cba5-4841-aa34-7312e65506bb",
     "gid": "yYjdJqf4qqFdyYjdJqfJjWF14y48u9yKjS0FfjIkYSTTVJ28E9U8k0888qq4K448qfKYWY2j",
     "a1": "189e23d294140zt169carg8ckkjwtp0gr7d2arl9n50000334644",
     "websectiga": "7750c37de43b7be9de8ed9ff8ea0e576519e8cd2157322eb972ecb429a7735d4",
     "webId": "5be414ee9dea89add826c174c443f76b",
     "web_session": "040069b5a1d3fc56b1bfc44aed374baf7d39cd",
     "xsecappid": "xhs-pc-web",
     "webBuild": "4.6.0",
     "acw_tc":"5f3d3b2f73520242752033111daf0192e3c0b08578d3ffc8ccd2c93c6e66e106",
     "gid":"yYjdJqf4qqFdyYjdJqfJjWF14y48u9yKjS0FfjIkYSTTVJ28E9U8k0888qq4K448qfKYWY2j",
     "abRequestId":"5be414ee9dea89add826c174c443f76b",
     "unread":"{%22ub%22:%2265eb303100000000030337ae%22%2C%22ue%22:%2265fabd6300000000130256ec%22%2C%22uc%22:18}"

}


js = execjs.compile(open(r'info.js', 'r', encoding='utf-8').read())

note_count = 0

# 向csv文件写入表头  笔记数据csv文件
header = ["评论","评论时间","笔记标题", "笔记链接","用户名", "IP属地","笔记内容"]
f=open(f"户外婚礼.csv", 'w', encoding="utf-8-sig", newline="")
writer = csv.DictWriter(f, header)
writer.writeheader()


# 时间戳转换成日期
def get_time(ctime):
    timeArray = time.localtime(int(ctime / 1000))
    otherStyleTime = time.strftime("%Y-%m-%d", timeArray)
    return str(otherStyleTime)


# 保存笔记数据
def get_note_info(note_id, title,user_name, user_id):
    note_url = f'https://www.xiaohongshu.com/explore/{note_id}'
    res = requests.get(note_url, headers=headers, cookies=cookies)
    bs = BeautifulSoup(res.text, "html.parser")  # 创建BeautifulSoup对象

    comment_url=f'https://edith.xiaohongshu.com/api/sns/web/v2/comment/page?note_id={note_id}&cursor=&top_comment_id=&image_formats=jpg,webp,avif'
    comment_res = requests.get(comment_url, headers=headers, cookies=cookies)
    comment_json_data = comment_res.json()
    commentsList = comment_json_data['data']['comments']
    content=bs.find('div', {'class': 'desc'})
    data_dict = {
        "评论":"",
        "评论时间":"",
        "笔记标题": title.strip(),
        "笔记链接": "https://www.xiaohongshu.com/explore/" + note_id,
        "用户名": user_name.strip(),
        "IP属地": "",
        "笔记内容": ""
    }
    if content is not None :
       content = content.get_text().strip().replace('\n', '')
       data_dict["笔记内容"]=content  
    time.sleep(1)
    # 笔记数量+1
    global note_count
    note_count += 1
    print("note_count",note_count)
    # print(f"当前笔记数量: {note_count}\n",
    #       f"笔记标题：{data_dict['笔记标题']}\n",
    #       f"笔记链接：{data_dict['笔记链接']}\n",
    #       f"用户头像：{data_dict['用户头像']}\n",
    #       f"用户名：{data_dict['用户名']}\n",
    #       f"IP属地：{data_dict['IP属地']}\n",
    #       f"笔记发布时间：{data_dict['笔记发布时间']}\n",
    #       f"笔记收藏数量：{data_dict['笔记收藏数量']}\n",
    #       f"笔记评论数量：{data_dict['笔记评论数量']}\n",
    #       f"笔记点赞数量：{data_dict['笔记点赞数量']}\n",
    #       f"笔记内容：{data_dict['笔记内容']}\n"
    #       )
    # start_date = "2024-03-01"
    # end_date = "2024-03-21"
    # check_date = data_dict['笔记发布时间']     
    # if is_date_in_range(start_date,end_date,check_date):
    #     writer.writerow(data_dict)
    #  for comment in commentsList: 
    writeRowHandler(commentsList,data_dict)
    
def writeRowHandler(commentsList,data_dict):
    for comment in commentsList:
        if hasattr(comment,"sub_comments"):
            writeRowHandler(comment["sub_comments"])
        else:
            check_date = get_time(comment["create_time"])
            data_dict["评论"]=comment["content"].strip()
            data_dict["评论时间"]=check_date
            start_date = "2022-03-14"
            end_date = "2024-03-22"
            print("check_date",check_date,is_date_in_range(start_date,end_date,check_date))
            if is_date_in_range(start_date,end_date,check_date):
                if comment["ip_location"]=='广东':
                    data_dict["IP属地"]=comment["ip_location"]
                    writer.writerow(data_dict) 

def is_date_in_range(start_date, end_date, check_date):
    # 将输入的日期字符串转换为datetime对象
    start_date = datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.strptime(end_date, "%Y-%m-%d")
    check_date = datetime.strptime(check_date, "%Y-%m-%d") 
    return start_date <= check_date <= end_date

def keyword_search(keyword,page,page_count):
    api = '/api/sns/web/v1/search/notes'

    search_url = "https://edith.xiaohongshu.com/api/sns/web/v1/search/notes"

    # 排序方式 general: 综合排序 popularity_descending: 热门排序 time_descending: 最新排序
    data = {
        "image_scenes": "FD_PRV_WEBP,FD_WM_WEBP",
        "keyword": "",
        "note_type": "0",
        "page": "",
        "page_size":"20",
        "search_id": "2c7hu5b3kzoivkh848hp0",
        "sort": "time_descending"
    }

    data = json.dumps(data, separators=(',', ':'))
    data = re.sub(r'"keyword":".*?"', f'"keyword":"{keyword}"', data)
    for page in range(page, page_count):
        print("page",page,page_count)
        data = re.sub(r'"page":".*?"', f'"page":"{page}"', data)

        ret = js.call('get_xs', api, data, cookies['a1'])
        headers['x-s'], headers['x-t'] = ret['X-s'], str(ret['X-t'])

        response = requests.post(search_url, headers=headers, cookies=cookies, data=data.encode('utf-8'))

        json_data = response.json()
        try:
            notes = json_data['data']['items']
        except:
            print('================爬取完毕================',page_count)
            if page_count < 200:
                time.sleep(10)
                page=page_count
                page_count +=20
                keyword_search(keyword,page,page_count)
            else:
                break

        for note in notes:
            note_id = note['id']
            if len(note_id) != 24:
                continue
            try:
                title = note['note_card']['display_title']
            except:
                title = ''

            user_avatar = note['note_card']['user']['avatar']
            user_name = note['note_card']['user']['nick_name']
            user_id = note['note_card']['user']['user_id']

            get_note_info(note_id, title,user_name, user_id)

def getTab():
    api = '/api/sns/web/v1/search/filters'
    filter_url = f'https://edith.xiaohongshu.com/api/sns/web/v1/search/filters?keyword={keyword}&search_id=2d06gwmdsahc7bb4v3s9v'
    # data = {
    #     "image_scenes": "FD_PRV_WEBP,FD_WM_WEBP",
    #     "keyword": "",
    #     "note_type": "0",
    #     "page": "",
    #     "page_size":"20",
    #     "search_id": "2c7hu5b3kzoivkh848hp0",
    #     "sort": "time_descending"
    # }
    # data = re.sub(r'"page":".*?"', f'"page":"{page}"', data)
    
    ret = js.call('get_xs', api, "", cookies['a1'])
    headers['x-s'], headers['x-t'] = ret['X-s'], str(ret['X-t'])
    response = requests.get(filter_url, headers=headers, cookies=cookies)
    filter_data = response.json()
    print("filter_data",filter_data)
    
def main():
    global keyword,page,page_count
    keyword = '户外婚礼'  # 搜索的关键词
    page=1
    page_count=30 # 爬取的页数, 一页有 20 条笔记 最多只能爬取220条笔记
    # getTab()
    keyword_search(keyword,page,page_count)


if __name__ == "__main__":
    main()





